# LoopU Final Complete (Flask + MongoDB, Purple Theme)
Run:
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp env.example .env
python app.py
Open http://127.0.0.1:5000
